@extends('layout.adminPageControl')
@section('content')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
    body, html {
        margin: 0;
        padding: 0;
        height: 100%;
        overflow: hidden;
    }
    .flatpickr-input[readonly] {
    cursor: pointer;
    width: 25%;
}
    .row {
        display: flex;
        height: 100vh;
        gap: 10px;
        padding: 10px;
        box-sizing: border-box;
    }
    .col-4 {
        flex: 1;
        overflow: hidden;
        cursor: pointer;
    }
    .full-screen {
        position: relative;
        width: 100%;
        height: 100%;
        overflow: hidden;
        border: 2px solid transparent;
        transition: border 0.3s ease, box-shadow 0.3s ease;
    }
    .full-screen img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: auto;
    }
    .selected {
        border: 2px solid #007BFF;
        box-shadow: 0 0 15px rgba(0, 123, 255, 0.5);
    }
</style>

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">Inquiries</h4>
                    </div>
                    <input type="text" id="datePicker" class="form-control" placeholder="Select Date">
                    <div class="table-responsive">
                        <table id="contactTable" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Date of Inquiry</th>
                                    <th>Client Name</th>
                                    <th>Contact Details</th>
                                    <th>Email</th>
                                    <th>Location</th>
                                    <th>Category</th>
                                    <th>Follow-up</th>  
                                </tr>
                            </thead>
                            <tbody id="contactTableBody">
                                @if(isset($contact))
                                    @foreach ($contact as $item)
                                    <tr>
                                        <td>{{ $item->id }}</td>
                                        <td>{{ \Carbon\Carbon::parse($item->created_at)->format('d M Y H:i') }}</td>
                                        <td>{{ $item->name }}</td>
                                        <td>{{ $item->phone_number }}</td>
                                        <td>{{ $item->email }}</td>
                                        <td>{{ $item->location }}</td>
                                        <td>{{ $item->category }}</td>
                                        <td><a href="{{route('client.follow', ['id' => $item->id ])}}" class="btn btn-primary">follow</a></td>
                                    </tr>
                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/2.1.4/css/dataTables.dataTables.min.css">

<!-- DataTables JS -->
<script src="https://cdn.datatables.net/2.1.4/js/dataTables.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<script>
    flatpickr("#datePicker", {
        mode: "range",
        dateFormat: "Y-m-d",
        onChange: function(selectedDates, dateStr, instance) {
        if (selectedDates.length === 2) {
                let startDate = selectedDates[0];
                let endDate = selectedDates[1];
                
                let startDateStr = flatpickr.formatDate(startDate, "Y-m-d");
                let endDateStr = flatpickr.formatDate(endDate, "Y-m-d");
                console.log("startDateStr : " + startDateStr);
                console.log("endDateStr : " + endDateStr);
                $.ajax({
                    url: "{{ route('inquiries.filter') }}",
                    method: "POST",
                    headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                    data: { startDate: startDateStr, endDate: endDateStr },
                    success: function(data) {
                        let tableBody = $('#contactTableBody');
                        tableBody.empty();  // Clear the table

                        data.forEach(function(item) {
                            let row = `<tr>
                                <td>${item.id}</td>
                                <td>${new Date(item.created_at).toLocaleString()}</td>
                                <td>${item.name}</td>
                                <td>${item.phone_number}</td>
                                <td>${item.email}</td>
                                <td>${item.location}</td>
                                <td>${item.category}</td>
                                <td><a href="/admin/followup/${item.id}" class="btn btn-primary">follow</a></td>
                            </tr>`;
                            tableBody.append(row);
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error("AJAX Error:", status);
                        console.error("AJAX Error:", xhr);
                        console.error("AJAX Error:", error);
                    }
                });
            }
        }
    });
    
</script>
<!-- Your Custom Script -->
<script>
$(document).ready(function() {
    $('#contactTable').DataTable({
        "order": [[ 0, "desc" ]],
        "paging": true,
        "searching": true,
        "info": true,
        "autoWidth": false,
        "lengthMenu": [5, 10, 25, 50],
        "columnDefs": [
            { "orderable": false, "targets": [2, 6] }
        ],
    });
});
</script>

@endsection
