<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contact;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $contact = Contact::get();
        return view('back-end.home.layout', compact('contact'));
    }
    public function followingClients(){
        $contact = Contact::where('status','following')->get();
        return view('back-end.home.following', compact('contact'));
    }
    public function completedClients(){
        $contact = Contact::where('status','completed')->get();
        return view('back-end.home.completed', compact('contact'));
    }
    public function rejectedClients(){
        $contact = Contact::where('status','rejected')->get();
        return view('back-end.home.rejected', compact('contact'));
    }
    public function pendingClients(){
        $contact = Contact::where('status','pending')->get();
        return view('back-end.home.pending', compact('contact'));
    }

public function inputContent(Request $req){
    $layout = $req->selected_layout;
    return view('back-end.home.content');
}
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
       dd($request);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
