<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\Contact;
use App\Models\FollowUp;

class ClinetFollowUp extends Controller
{
        public function client($id) {
            $client = Contact::where('id',$id)->first();
            $followup = FollowUp::where('client_id',$id)->get();
            return view('back-end.followup',compact('client','followup'));
        }
    public function filterInquiries(Request $req)
    {
        $validated = $req->validate([
            'startDate' => 'required|date',
            'endDate' => 'required|date',
        ]);
    
        $start = $validated['startDate'];
        $end = $validated['endDate'];
        $end = \Carbon\Carbon::parse($end)->endOfDay();
    
        if ($start === $end) {
            $contacts = Contact::whereDate('created_at', $start)->get();
        } else {
            $contacts = Contact::whereBetween('created_at', [$start, $end])->get();
        }
            return response()->json($contacts);
    }
    public function clientStatus(Request $req)
    {
        // Validate the incoming request
        $req->validate([
            'client_id' => 'required|exists:contacts,id',
            'status' => 'required|string|in:following,rejected,pending,completed',
        ]);

        // Find the contact by ID and update the status
        $contact = Contact::find($req->client_id);

        if ($contact) {
            $contact->status = $req->status;
            $contact->save();

            return response()->json(['success' => true, 'message' => 'Client status updated successfully.']);
        }

        // If the client is not found, return an error response
        return response()->json(['success' => false, 'message' => 'Client not found.'], 404);
    }
}
